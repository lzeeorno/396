396 Assignment 1
group menber(ccid, student number):
  1.Dai Xu (xdai2,1495688)
  2.Zheng Fuchen(1465251)
